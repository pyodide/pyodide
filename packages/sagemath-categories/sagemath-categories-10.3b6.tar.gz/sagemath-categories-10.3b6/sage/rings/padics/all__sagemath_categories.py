from sage.rings.padics.padic_generic import local_print_mode
