from sage.calculus.functional import diff, derivative, expand, simplify, taylor
