from sage.schemes.generic.all import *
from sage.schemes.affine.all import *
from sage.schemes.projective.all import *
from sage.schemes.product_projective.all import *
