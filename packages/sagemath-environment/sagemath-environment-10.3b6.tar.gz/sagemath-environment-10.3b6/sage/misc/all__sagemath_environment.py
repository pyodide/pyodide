from sage.misc.temporary_file import tmp_dir, tmp_filename
