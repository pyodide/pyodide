# Resolve a cyclic import
import sage.structure.element
