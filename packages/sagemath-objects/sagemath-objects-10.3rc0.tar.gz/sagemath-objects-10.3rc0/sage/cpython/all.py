from sage.cpython.debug import getattr_debug, type_debug
from sage.cpython.getattr import raw_getattr
